<?php
/*
Plugin Name: Divinity IA Assistant
Description: Incorpora un chat, potenciado por chat GTP-4 para aconsejar y ayudar a un cliente
*/

// Llamada al fichero con funciones del plugin.
require_once plugin_dir_path(__FILE__) . 'includes/aai-funciones.php';
?>
